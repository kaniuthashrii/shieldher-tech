// Require auth on page load
requireAuth();

// DOM elements
const dropZone = document.getElementById("upload-zone");
const fileInput = document.getElementById("file-input");
const filePreview = document.getElementById("file-preview");
const previewImg = document.getElementById("preview-img");
const fileName = document.getElementById("file-name");
const fileSize = document.getElementById("file-size");
const scanBtn = document.getElementById("scan-btn");

let currentFile = null;

// --- STEP 1: Upload image ---
const uploadImage = async (file) => {
  try {
    const formData = new FormData()
    formData.append("file", file) // backend expects 'file'
    
    // UI Loading state
    if (typeof showToast === 'function') showToast("Uploading image...", "info");
    if (scanBtn) {
        scanBtn.innerHTML = '<span class="spinner"></span> Uploading...';
        scanBtn.disabled = true;
    }
    
    // Make API call
    const data = await window.uploadFile("/upload", formData);
    
    if (data.success) {
      if (typeof showToast === 'function') showToast("Upload complete! Starting scan...", "success");
      await triggerScan(data.data.image.id) // Auto-trigger scan
    }
  } catch (err) {
    if (typeof showToast === 'function') showToast(err.message, "error");
    if (scanBtn) {
        scanBtn.innerHTML = '<span class="scan-icon">🔍</span> Scan Image Now';
        scanBtn.disabled = false;
    }
  }
}

// --- STEP 2: Auto-trigger scan after upload ---
const triggerScan = async (image_id) => {
  try {
    if (scanBtn) {
        scanBtn.innerHTML = '<span class="spinner"></span> Scanning Network...';
    }
    
    const data = await window.apiCall(`/scan/${image_id}`, "POST");
    
    if (typeof showToast === 'function') {
        if (data.data.scan.status === "safe") {
            showToast("✅ Image is Safe!", "success");
        } else if (data.data.scan.status === "suspicious") {
            showToast("⚠️ Suspicious Match Found!", "warning");
        } else {
            showToast("🚨 Deepfake Detected!", "error");
        }
    }

    // Redirect to dashboard to see results after 2 seconds
    setTimeout(() => {
        window.location.href = "dashboard.html";
    }, 2000);

  } catch (err) {
    if (typeof showToast === 'function') showToast("Scan failed: " + err.message, "error");
    if (scanBtn) {
        scanBtn.innerHTML = '<span class="scan-icon">🔍</span> Scan Failed — Try Again';
        scanBtn.disabled = false;
    }
  }
}

// --- Event Listeners ---
// --- Event Listeners ---
if (dropZone) dropZone.addEventListener("click", () => fileInput.click());

dropZone.addEventListener("dragover", (e) => {
  e.preventDefault()
  dropZone.classList.add("drag-over")
})

dropZone.addEventListener("dragleave", (e) => {
  e.preventDefault()
  dropZone.classList.remove("drag-over")
})

dropZone.addEventListener("drop", (e) => {
  e.preventDefault()
  dropZone.classList.remove("drag-over")
  
  if (e.dataTransfer.files.length) {
    handleFileSelection(e.dataTransfer.files[0])
  }
})

fileInput.addEventListener("change", (e) => {
  if (e.target.files.length) {
    handleFileSelection(e.target.files[0])
  }
})

function handleFileSelection(file) {
    if (!file.type.startsWith('image/')) {
        if (typeof showToast === 'function') showToast('Please select an image file', 'error');
        return;
    }
    currentFile = file;

    // Show preview
    const reader = new FileReader();
    reader.onload = (e) => {
        previewImg.src = e.target.result;
        fileName.textContent = file.name;
        fileSize.textContent = (file.size / (1024 * 1024)).toFixed(2) + ' MB';
        
        dropZone.style.display = 'none';
        filePreview.classList.add('show');
        
        // Enable the scan button now that a file is ready
        if (scanBtn) {
            scanBtn.disabled = false;
        }
    };
    reader.readAsDataURL(file);
}

// Attach manual scan button listener (if auto-scan isn't wanted immediately)
if (scanBtn) {
    scanBtn.addEventListener("click", () => {
        if (currentFile) {
            uploadImage(currentFile);
        }
    });
}
