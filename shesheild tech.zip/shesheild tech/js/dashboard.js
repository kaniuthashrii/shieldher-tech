// Load all dashboard data on page load
const loadDashboard = async () => {
  requireAuth()
  
  // Set user name in UI if available
  const userStr = localStorage.getItem("sheshield_user");
  if (userStr) {
      try {
          const user = JSON.parse(userStr);
          const nameEls = document.querySelectorAll('.user-name-display');
          nameEls.forEach(el => el.textContent = user.name.split(' ')[0]);
      } catch (e) {}
  }

  try {
      await Promise.all([
        loadStats(),
        loadRecentScans(),
        loadLiveAlerts()
      ])
  } catch (err) {
      console.error("Dashboard Load Error:", err);
      if (typeof showToast === 'function') {
          showToast("Failed to load dashboard data.", "error");
      }
  }
}

// Live Alerts for right panel
const loadLiveAlerts = async () => {
    const data = await apiCall("/alerts")
    const alertList = document.getElementById("alert-list")
    if (!alertList) return;

    if (data.data.alerts.length === 0) {
        alertList.innerHTML = `<div style="text-align:center; padding: 20px; color: var(--color-text-muted);">No live alerts!</div>`;
        return;
    }

    alertList.innerHTML = data.data.alerts.slice(0, 5).map((alert, i) => {
        const isCritical = alert.severity === 'HIGH';
        const d = new Date(alert.created_at);
        const timeStr = d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
        
        return `
        <div class="mini-alert ${isCritical ? 'critical' : ''} animate-fade-in-up" style="animation-delay: ${0.3 + i * 0.15}s">
          <div class="mini-alert-header">
            <span class="mini-alert-title">${isCritical ? '🚨' : '⚠️'} ${alert.platform} Match</span>
            <span class="mini-alert-time">${timeStr}</span>
          </div>
          <div class="mini-alert-desc">${alert.message}</div>
          <div style="margin-top:var(--space-sm)">
            <span class="badge ${isCritical ? 'badge-high' : 'badge-medium'}">${alert.severity}</span>
          </div>
        </div>
        `
    }).join("")
}

// Animated count-up stats
const loadStats = async () => {
  const data = await apiCall("/dashboard/stats")
  const { total_scanned, threats_found, alerts_sent } = data.data
  
  animateCount("stat-scanned", total_scanned)
  animateCount("stat-threats", threats_found)
  animateCount("stat-alerts", alerts_sent)
  updateDonutChart(total_scanned, alerts_sent, threats_found - alerts_sent, total_scanned - threats_found)
}

// Update Donut Chart
const updateDonutChart = (total, high, medium, safeCount) => {
    const circumference = 2 * Math.PI * 48; // ~301.6
    
    // Update center number
    const centerNum = document.querySelector('.donut-number');
    if (centerNum) centerNum.textContent = total;

    if (total === 0) return; // leave as empty rings

    const safeRatio = safeCount / total * circumference;
    const riskRatio = medium / total * circumference;
    const deepfakeRatio = high / total * circumference;

    const safeCircle = document.getElementById('donut-safe');
    const riskCircle = document.getElementById('donut-risk');
    const deepfakeCircle = document.getElementById('donut-deepfake');

    if (safeCircle) safeCircle.setAttribute('stroke-dasharray', `${safeRatio} ${circumference}`);
    
    if (riskCircle) {
        riskCircle.setAttribute('stroke-dasharray', `${riskRatio} ${circumference}`);
        riskCircle.setAttribute('stroke-dashoffset', `-${safeRatio}`);
    }

    if (deepfakeCircle) {
        deepfakeCircle.setAttribute('stroke-dasharray', `${deepfakeRatio} ${circumference}`);
        deepfakeCircle.setAttribute('stroke-dashoffset', `-${safeRatio + riskRatio}`);
    }

    // Update legend labels
    const legends = document.querySelectorAll('.legend-item');
    if (legends.length === 3) {
        legends[0].innerHTML = `<span class="legend-dot" style="background: var(--color-success)"></span>Safe — ${safeCount} (${Math.round(safeCount/total*100)}%)`;
        legends[1].innerHTML = `<span class="legend-dot" style="background: var(--color-warning)"></span>Suspicious — ${medium} (${Math.round(medium/total*100)}%)`;
        legends[2].innerHTML = `<span class="legend-dot" style="background: var(--color-danger)"></span>Deepfake — ${high} (${Math.round(high/total*100)}%)`;
    }
}

// Recent scans table
const loadRecentScans = async () => {
  const data = await apiCall("/scan/results")
  const tableBody = document.querySelector(".data-table tbody")
  const skeleton = document.getElementById("skeleton-loader")
  const scansTable = document.getElementById("scans-table")
  
  if (!tableBody) return;

  // Hide skeleton, show table
  if (skeleton) skeleton.style.display = "none";
  if (scansTable) scansTable.style.display = "block";

  if (data.data.results.length === 0) {
      tableBody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: var(--color-text-muted);">No scans yet. <a href="/upload.html">Upload a photo</a> to get started.</td></tr>`;
      return;
  }
  
  tableBody.innerHTML = data.data.results.slice(0, 10).map(scan => {
    // Determine badge class
    let badgeClass = "badge-safe";
    if (scan.status === "suspicious") badgeClass = "badge-warning";
    if (scan.status === "deepfake") badgeClass = "badge-danger";

    // Format date
    const d = new Date(scan.scanned_at);
    const dateStr = d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});

    return `
    <tr>
      <td>
        <div style="display: flex; align-items: center; gap: 10px;">
           <div class="thumb" style="display: flex; align-items: center; justify-content: center; background: rgba(255,255,255,0.1); font-size: 1.5rem;">📸</div>
           <span>Scan #${scan.id.substring(0, 6)}</span>
        </div>
      </td>
      <td>${dateStr}</td>
      <td><span class="badge ${badgeClass}">${scan.status.toUpperCase()}</span></td>
      <td>${(scan.deepfake_score * 100).toFixed(1)}%</td>
    </tr>
  `
  }).join("")
}

// Animated number counter
const animateCount = (elementId, target) => {
  let count = 0
  const el = document.getElementById(elementId)
  if (!el) return;
  
  if (target === 0) {
      el.textContent = "0";
      return;
  }

  const interval = setInterval(() => {
    count += Math.ceil(target / 20)
    if (count >= target) { count = target; clearInterval(interval) }
    el.textContent = count
  }, 40)
}

document.addEventListener("DOMContentLoaded", loadDashboard)
