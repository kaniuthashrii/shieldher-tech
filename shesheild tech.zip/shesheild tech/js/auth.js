// REGISTER
const register = async (name, email, password) => {
  try {
    const data = await apiCall("/auth/register", "POST", { name, email, password })
    localStorage.setItem("sheshield_token", data.data.access_token)
    localStorage.setItem("sheshield_user", JSON.stringify(data.data.user))
    window.location.href = "/dashboard.html"
  } catch (error) {
    if (typeof showToast === 'function') {
      showToast(error.message, "error")
    } else {
      alert("Registration failed: " + error.message)
    }
    throw error
  }
}

// LOGIN
const login = async (email, password) => {
  try {
    const data = await apiCall("/auth/login", "POST", { email, password })
    localStorage.setItem("sheshield_token", data.data.access_token)
    localStorage.setItem("sheshield_user", JSON.stringify(data.data.user))
    window.location.href = "/dashboard.html"
  } catch (error) {
    if (typeof showToast === 'function') {
        showToast(error.message, "error")
    } else {
        alert("Login failed: " + error.message)
    }
    throw error
  }
}

// LOGOUT
const logout = () => {
  localStorage.removeItem("sheshield_token")
  localStorage.removeItem("sheshield_user")
  window.location.href = "/index.html"
}

// GUARD — add this to dashboard, upload, alerts pages
const requireAuth = () => {
  if (!localStorage.getItem("sheshield_token")) {
    window.location.href = "/index.html"
  }
}

// Check if already logged in for index.html
// Now disabled so logged-in users can view the landing page
const checkAlreadyLoggedIn = () => {
  // Intentionally blank
}

// Make accessible globally
window.register = register;
window.login = login;
window.logout = logout;
window.requireAuth = requireAuth;
window.checkAlreadyLoggedIn = checkAlreadyLoggedIn;
