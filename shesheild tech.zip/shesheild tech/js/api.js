const BASE_URL = "http://localhost:5000/api"

// Get JWT token from localStorage
const getToken = () => localStorage.getItem("sheshield_token")

// Reusable fetch wrapper
const apiCall = async (endpoint, method = "GET", body = null) => {
  const headers = {
    "Content-Type": "application/json"
  }
  
  const token = getToken()
  if (token) {
    headers["Authorization"] = `Bearer ${token}`
  }
  
  const options = { method, headers }
  if (body) options.body = JSON.stringify(body)
  
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, options)
    const data = await response.json()
    
    if (!response.ok) {
      // Auto-logout on token expiration (401)
      if (response.status === 401 && endpoint !== "/auth/login") {
         localStorage.removeItem("sheshield_token");
         localStorage.removeItem("sheshield_user");
         window.location.href = "/index.html";
      }
      throw new Error(data.error || "Something went wrong")
    }
    return data
  } catch (error) {
    console.error("API Error:", error)
    throw error // Re-throw to be handled by the caller
  }
}

// For file uploads (no Content-Type header — let browser set it)
const uploadFile = async (endpoint, formData) => {
  try {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${getToken()}` },
      body: formData
    })
    const data = await response.json()
    
    if (!response.ok) throw new Error(data.error || "Upload failed")
    return data
  } catch (error) {
    console.error("Upload Error:", error)
    throw error
  }
}

// Make accessible globally
window.apiCall = apiCall;
window.uploadFile = uploadFile;
window.getToken = getToken;
