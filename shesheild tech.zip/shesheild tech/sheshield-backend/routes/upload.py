"""
Image Upload Routes
POST   /api/upload      → Upload image, generate fingerprint
GET    /api/images      → Get all uploaded images for current user
DELETE /api/images/<id> → Delete an image record
"""

import os
import uuid

from flask import Blueprint, request, current_app, g
from flask_jwt_extended import jwt_required, get_jwt_identity
from werkzeug.utils import secure_filename

from models.image import Image
from services.fingerprint import generate_fingerprint

upload_bp = Blueprint("upload", __name__, url_prefix="/api")


def _allowed_file(filename: str) -> bool:
    """Check if the file extension is allowed."""
    if "." not in filename:
        return False
    ext = filename.rsplit(".", 1)[1].lower()
    return ext in current_app.config["ALLOWED_EXTENSIONS"]


@upload_bp.route("/upload", methods=["POST"])
@jwt_required()
def upload_image():
    """Upload an image, generate its fingerprint, and store the record."""
    user_id = get_jwt_identity()

    if "file" not in request.files:
        return {"success": False, "error": "No file provided", "code": 400}, 400

    file = request.files["file"]

    if file.filename == "":
        return {"success": False, "error": "No file selected", "code": 400}, 400

    if not _allowed_file(file.filename):
        return {
            "success": False,
            "error": "Invalid file type. Allowed: jpg, jpeg, png",
            "code": 400,
        }, 400

    # Generate a safe UUID filename
    ext = file.filename.rsplit(".", 1)[1].lower()
    safe_filename = f"{uuid.uuid4().hex}.{ext}"

    # Ensure upload directory exists
    upload_folder = current_app.config.get("UPLOAD_FOLDER", "uploads")
    os.makedirs(upload_folder, exist_ok=True)

    file_path = os.path.join(upload_folder, safe_filename)
    # Save the file first
    file.save(file_path)

    # Generate fingerprint (pHash + ORB feature vector)
    try:
        fingerprint = generate_fingerprint(file_path)
    except Exception as e:
        fingerprint = {"phash": None, "feature_vector": []}

    # Store in database
    db = g.db
    image = Image.create(
        db,
        user_id=user_id,
        filename=safe_filename,
        file_path=file_path,
        phash=fingerprint["phash"],
        feature_vector=fingerprint["feature_vector"],
    )

    return {
        "success": True,
        "data": {
            "image": Image.to_json(image),
            "fingerprint": {
                "phash": fingerprint["phash"],
                "features_extracted": len(fingerprint["feature_vector"]) > 0,
            },
        },
        "message": "Image uploaded and fingerprinted successfully",
    }, 201


@upload_bp.route("/images", methods=["GET"])
@jwt_required()
def get_images():
    """Get all uploaded images for the logged-in user."""
    user_id = get_jwt_identity()
    db = g.db

    images = Image.find_by_user(db, user_id)
    return {
        "success": True,
        "data": {
            "images": [Image.to_json(img) for img in images],
            "total": len(images),
        },
        "message": "Images retrieved successfully",
    }, 200


@upload_bp.route("/images/<image_id>", methods=["DELETE"])
@jwt_required()
def delete_image(image_id):
    """Delete an image record owned by the current user."""
    user_id = get_jwt_identity()
    db = g.db

    # Also remove file from disk
    image = Image.find_by_id(db, image_id)
    if image and str(image["user_id"]) == user_id:
        file_path = image.get("file_path", "")
        if file_path and os.path.exists(file_path):
            os.remove(file_path)

    deleted = Image.delete(db, image_id, user_id)
    if not deleted:
        return {"success": False, "error": "Image not found or access denied", "code": 404}, 404

    return {
        "success": True,
        "data": None,
        "message": "Image deleted successfully",
    }, 200
