"""
Alert Routes
GET   /api/alerts          → Get all alerts for the current user
POST  /api/alerts          → Manually create an alert
PATCH /api/alerts/<id>/read → Mark an alert as read
"""

from flask import Blueprint, request, g
from flask_jwt_extended import jwt_required, get_jwt_identity

from models.alert import Alert

alerts_bp = Blueprint("alerts", __name__, url_prefix="/api/alerts")


@alerts_bp.route("", methods=["GET"])
@jwt_required()
def get_alerts():
    """Get all alerts for the logged-in user."""
    user_id = get_jwt_identity()
    db = g.db

    alerts = Alert.find_by_user(db, user_id)

    return {
        "success": True,
        "data": {
            "alerts": [Alert.to_json(a) for a in alerts],
            "total": len(alerts),
        },
        "message": "Alerts retrieved successfully",
    }, 200


@alerts_bp.route("", methods=["POST"])
@jwt_required()
def create_alert():
    """Manually create a new alert (e.g., from external report)."""
    user_id = get_jwt_identity()
    data = request.get_json(silent=True)

    if not data:
        return {"success": False, "error": "Request body is required", "code": 400}, 400

    image_id = data.get("image_id", "")
    severity = data.get("severity", "").upper()
    platform = data.get("platform", "Unknown")
    message = data.get("message", "")

    # Validate
    if not image_id or not message:
        return {"success": False, "error": "image_id and message are required", "code": 400}, 400

    if severity not in (Alert.SEVERITY_LOW, Alert.SEVERITY_MEDIUM, Alert.SEVERITY_HIGH):
        return {
            "success": False,
            "error": f"severity must be LOW, MEDIUM, or HIGH",
            "code": 400,
        }, 400

    db = g.db
    alert = Alert.create(db, user_id, image_id, severity, platform, message)

    return {
        "success": True,
        "data": {"alert": Alert.to_json(alert)},
        "message": "Alert created successfully",
    }, 201


@alerts_bp.route("/<alert_id>/read", methods=["PATCH"])
@jwt_required()
def mark_alert_read(alert_id):
    """Mark a specific alert as read."""
    user_id = get_jwt_identity()
    db = g.db

    updated = Alert.mark_as_read(db, alert_id, user_id)
    if not updated:
        return {"success": False, "error": "Alert not found or already read", "code": 404}, 404

    return {
        "success": True,
        "data": None,
        "message": "Alert marked as read",
    }, 200
