"""
Authentication Routes
POST /api/auth/register  → Register new user
POST /api/auth/login     → Login, return JWT
POST /api/auth/logout    → Invalidate token (client-side)
"""

from datetime import timedelta

from flask import Blueprint, request, current_app, g
from flask_jwt_extended import (
    create_access_token,
    jwt_required,
    get_jwt_identity,
)

from models.user import User

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")


@auth_bp.route("/register", methods=["POST"])
def register():
    """Register a new user."""
    data = request.get_json(silent=True)
    if not data:
        return {"success": False, "error": "Request body is required", "code": 400}, 400

    name = (data.get("name") or "").strip()
    email = (data.get("email") or "").strip()
    password = data.get("password", "")

    # Validation
    if not name or not email or not password:
        return {"success": False, "error": "Name, email, and password are required", "code": 400}, 400

    if len(password) < 6:
        return {"success": False, "error": "Password must be at least 6 characters", "code": 400}, 400

    if "@" not in email or "." not in email:
        return {"success": False, "error": "Invalid email format", "code": 400}, 400

    db = g.db

    # Check if user already exists
    existing = User.find_by_email(db, email)
    if existing:
        return {"success": False, "error": "Email already registered", "code": 409}, 409

    # Create user
    user = User.create(db, name, email, password)

    # Generate JWT
    access_token = create_access_token(
        identity=str(user["_id"]),
        expires_delta=timedelta(seconds=current_app.config["JWT_ACCESS_TOKEN_EXPIRES"]),
    )

    return {
        "success": True,
        "data": {
            "user": User.to_json(user),
            "access_token": access_token,
        },
        "message": "Registration successful",
    }, 201


@auth_bp.route("/login", methods=["POST"])
def login():
    """Authenticate user and return JWT token."""
    data = request.get_json(silent=True)
    if not data:
        return {"success": False, "error": "Request body is required", "code": 400}, 400

    email = (data.get("email") or "").strip()
    password = data.get("password", "")

    if not email or not password:
        return {"success": False, "error": "Email and password are required", "code": 400}, 400

    db = g.db
    user = User.find_by_email(db, email)

    if not user or not User.check_password(user["password_hash"], password):
        return {"success": False, "error": "Invalid email or password", "code": 401}, 401

    access_token = create_access_token(
        identity=str(user["_id"]),
        expires_delta=timedelta(seconds=current_app.config["JWT_ACCESS_TOKEN_EXPIRES"]),
    )

    return {
        "success": True,
        "data": {
            "user": User.to_json(user),
            "access_token": access_token,
        },
        "message": "Login successful",
    }, 200


@auth_bp.route("/logout", methods=["POST"])
@jwt_required()
def logout():
    """
    Logout — JWT is stateless, so this is handled client-side by
    discarding the token. This endpoint exists for API completeness.
    """
    return {
        "success": True,
        "data": None,
        "message": "Logged out successfully. Please discard your token.",
    }, 200
