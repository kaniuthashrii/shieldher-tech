"""
Scan Routes
POST /api/scan/<image_id>  → Run full scan (similarity + deepfake detection)
GET  /api/scan/results     → Get all scan results for the current user
"""

from flask import Blueprint, current_app, g
from flask_jwt_extended import jwt_required, get_jwt_identity

from models.image import Image
from models.scan_result import ScanResult
from models.alert import Alert
from services.deepfake import detect_deepfake
from services.similarity import find_similar_images, get_similarity_score

scan_bp = Blueprint("scan", __name__, url_prefix="/api/scan")


@scan_bp.route("/<image_id>", methods=["POST"])
@jwt_required()
def run_scan(image_id):
    """
    Run a full scan on the given image:
    1. Similarity scan (compare pHash against all stored hashes)
    2. Deepfake detection (CNN model prediction)
    3. Auto-create alerts based on results
    """
    user_id = get_jwt_identity()
    db = g.db

    # Find the image
    image = Image.find_by_id(db, image_id)
    if not image or str(image["user_id"]) != user_id:
        return {"success": False, "error": "Image not found or access denied", "code": 404}, 404

    # --- 1. Similarity Scan ---
    similarity_matches = []
    similarity_score = 0.0

    if image.get("phash"):
        all_images = Image.get_all_hashes(db)
        similarity_matches = find_similar_images(
            target_phash=image["phash"],
            all_images=all_images,
            exclude_id=image["_id"],
            threshold=10,
        )
        similarity_score = get_similarity_score(similarity_matches)

    # --- 2. Deepfake Detection ---
    mock_mode = current_app.config.get("MOCK_MODE", True)
    model_path = current_app.config.get("MODEL_PATH", "ml_model/model.h5")

    deepfake_result = detect_deepfake(
        image_path=image["file_path"],
        model_path=model_path,
        mock_mode=mock_mode,
    )

    # --- 3. Determine Overall Status ---
    deepfake_score = deepfake_result["deepfake_score"]
    deepfake_label = deepfake_result["label"]

    if deepfake_label == "deepfake":
        status = ScanResult.STATUS_DEEPFAKE
    elif deepfake_label == "suspicious" or len(similarity_matches) > 0:
        status = ScanResult.STATUS_SUSPICIOUS
    else:
        status = ScanResult.STATUS_SAFE

    # --- 4. Store Scan Result ---
    scan = ScanResult.create(
        db,
        image_id=image_id,
        user_id=user_id,
        similarity_score=similarity_score,
        deepfake_score=deepfake_score,
        status=status,
    )

    # --- 5. Auto-Create Alerts ---
    alerts_created = []

    if deepfake_label == "deepfake":
        alert = Alert.create(
            db,
            user_id=user_id,
            image_id=image_id,
            severity=Alert.SEVERITY_HIGH,
            platform="AI Scan",
            message=f"Deepfake detected on image '{image['filename']}' "
                    f"with {deepfake_score:.1%} confidence.",
        )
        alerts_created.append(Alert.to_json(alert))

    elif deepfake_label == "suspicious":
        alert = Alert.create(
            db,
            user_id=user_id,
            image_id=image_id,
            severity=Alert.SEVERITY_MEDIUM,
            platform="AI Scan",
            message=f"Suspicious patterns detected on image '{image['filename']}'. "
                    f"Deepfake score: {deepfake_score:.1%}.",
        )
        alerts_created.append(Alert.to_json(alert))

    if similarity_matches:
        severity = Alert.SEVERITY_HIGH if similarity_matches[0]["distance"] < 5 else Alert.SEVERITY_MEDIUM
        alert = Alert.create(
            db,
            user_id=user_id,
            image_id=image_id,
            severity=severity,
            platform="Similarity Scan",
            message=f"Found {len(similarity_matches)} similar image(s). "
                    f"Closest match: {similarity_matches[0]['similarity_pct']}% similar.",
        )
        alerts_created.append(Alert.to_json(alert))

    return {
        "success": True,
        "data": {
            "scan": ScanResult.to_json(scan),
            "deepfake": deepfake_result,
            "similarity": {
                "matches": similarity_matches,
                "score": similarity_score,
            },
            "alerts_created": alerts_created,
        },
        "message": f"Scan complete — Status: {status.upper()}",
    }, 200


@scan_bp.route("/results", methods=["GET"])
@jwt_required()
def get_scan_results():
    """Get all scan results for the logged-in user."""
    user_id = get_jwt_identity()
    db = g.db

    results = ScanResult.find_by_user(db, user_id)

    return {
        "success": True,
        "data": {
            "results": [ScanResult.to_json(r) for r in results],
            "total": len(results),
        },
        "message": "Scan results retrieved successfully",
    }, 200
