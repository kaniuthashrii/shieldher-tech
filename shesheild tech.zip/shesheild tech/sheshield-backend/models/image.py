from datetime import datetime, timezone

from bson import ObjectId


class Image:
    """Image model — maps to the 'images' MongoDB collection."""

    collection_name = "images"

    @staticmethod
    def create(db, user_id: str, filename: str, file_path: str,
               phash: str = None, feature_vector: list = None) -> dict:
        """Create a new image record with fingerprint data."""
        image_doc = {
            "user_id": ObjectId(user_id),
            "filename": filename,
            "file_path": file_path,
            "phash": phash,
            "feature_vector": feature_vector,
            "uploaded_at": datetime.now(timezone.utc),
        }
        result = db[Image.collection_name].insert_one(image_doc)
        image_doc["_id"] = result.inserted_id
        return image_doc

    @staticmethod
    def find_by_user(db, user_id: str) -> list:
        """Get all images belonging to a user."""
        return list(
            db[Image.collection_name]
            .find({"user_id": ObjectId(user_id)})
            .sort("uploaded_at", -1)
        )

    @staticmethod
    def find_by_id(db, image_id: str):
        """Find a single image by its ObjectId."""
        return db[Image.collection_name].find_one({"_id": ObjectId(image_id)})

    @staticmethod
    def delete(db, image_id: str, user_id: str) -> bool:
        """Delete an image record owned by the given user."""
        result = db[Image.collection_name].delete_one(
            {"_id": ObjectId(image_id), "user_id": ObjectId(user_id)}
        )
        return result.deleted_count > 0

    @staticmethod
    def get_all_hashes(db) -> list:
        """Retrieve all image records that have a phash (for similarity scan)."""
        return list(
            db[Image.collection_name].find(
                {"phash": {"$ne": None}},
                {"_id": 1, "user_id": 1, "phash": 1, "filename": 1}
            )
        )

    @staticmethod
    def to_json(image: dict) -> dict:
        """Serialize an image document for API responses."""
        return {
            "id": str(image["_id"]),
            "user_id": str(image["user_id"]),
            "filename": image["filename"],
            "file_path": image.get("file_path", ""),
            "phash": image.get("phash"),
            "uploaded_at": image["uploaded_at"].isoformat(),
        }
