from datetime import datetime, timezone

from bson import ObjectId


class ScanResult:
    """Scan result model — maps to the 'scan_results' MongoDB collection."""

    collection_name = "scan_results"

    STATUS_SAFE = "safe"
    STATUS_SUSPICIOUS = "suspicious"
    STATUS_DEEPFAKE = "deepfake"

    @staticmethod
    def create(db, image_id: str, user_id: str, similarity_score: float,
               deepfake_score: float, status: str) -> dict:
        """Create a new scan result record."""
        scan_doc = {
            "image_id": ObjectId(image_id),
            "user_id": ObjectId(user_id),
            "similarity_score": similarity_score,
            "deepfake_score": deepfake_score,
            "status": status,
            "scanned_at": datetime.now(timezone.utc),
        }
        result = db[ScanResult.collection_name].insert_one(scan_doc)
        scan_doc["_id"] = result.inserted_id
        return scan_doc

    @staticmethod
    def find_by_user(db, user_id: str) -> list:
        """Get all scan results for a user, newest first."""
        return list(
            db[ScanResult.collection_name]
            .find({"user_id": ObjectId(user_id)})
            .sort("scanned_at", -1)
        )

    @staticmethod
    def count_by_user(db, user_id: str) -> int:
        """Count total scans for a user."""
        return db[ScanResult.collection_name].count_documents(
            {"user_id": ObjectId(user_id)}
        )

    @staticmethod
    def count_threats(db, user_id: str) -> int:
        """Count scans with status 'suspicious' or 'deepfake' for a user."""
        return db[ScanResult.collection_name].count_documents(
            {
                "user_id": ObjectId(user_id),
                "status": {"$in": [ScanResult.STATUS_SUSPICIOUS, ScanResult.STATUS_DEEPFAKE]},
            }
        )

    @staticmethod
    def to_json(scan: dict) -> dict:
        """Serialize a scan result document for API responses."""
        return {
            "id": str(scan["_id"]),
            "image_id": str(scan["image_id"]),
            "user_id": str(scan["user_id"]),
            "similarity_score": scan["similarity_score"],
            "deepfake_score": scan["deepfake_score"],
            "status": scan["status"],
            "scanned_at": scan["scanned_at"].isoformat(),
        }
