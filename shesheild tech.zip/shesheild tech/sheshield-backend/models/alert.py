from datetime import datetime, timezone

from bson import ObjectId


class Alert:
    """Alert model — maps to the 'alerts' MongoDB collection."""

    collection_name = "alerts"

    SEVERITY_LOW = "LOW"
    SEVERITY_MEDIUM = "MEDIUM"
    SEVERITY_HIGH = "HIGH"

    @staticmethod
    def create(db, user_id: str, image_id: str, severity: str,
               platform: str, message: str) -> dict:
        """Create a new alert record."""
        alert_doc = {
            "user_id": ObjectId(user_id),
            "image_id": ObjectId(image_id),
            "severity": severity,
            "platform": platform,
            "message": message,
            "is_read": False,
            "created_at": datetime.now(timezone.utc),
        }
        result = db[Alert.collection_name].insert_one(alert_doc)
        alert_doc["_id"] = result.inserted_id
        return alert_doc

    @staticmethod
    def find_by_user(db, user_id: str) -> list:
        """Get all alerts for a user, newest first."""
        return list(
            db[Alert.collection_name]
            .find({"user_id": ObjectId(user_id)})
            .sort("created_at", -1)
        )

    @staticmethod
    def mark_as_read(db, alert_id: str, user_id: str) -> bool:
        """Mark a specific alert as read."""
        result = db[Alert.collection_name].update_one(
            {"_id": ObjectId(alert_id), "user_id": ObjectId(user_id)},
            {"$set": {"is_read": True}},
        )
        return result.modified_count > 0

    @staticmethod
    def count_by_user(db, user_id: str) -> int:
        """Count total alerts for a user."""
        return db[Alert.collection_name].count_documents(
            {"user_id": ObjectId(user_id)}
        )

    @staticmethod
    def to_json(alert: dict) -> dict:
        """Serialize an alert document for API responses."""
        return {
            "id": str(alert["_id"]),
            "user_id": str(alert["user_id"]),
            "image_id": str(alert["image_id"]),
            "severity": alert["severity"],
            "platform": alert["platform"],
            "message": alert["message"],
            "is_read": alert["is_read"],
            "created_at": alert["created_at"].isoformat(),
        }
