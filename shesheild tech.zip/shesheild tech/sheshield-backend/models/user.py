from datetime import datetime, timezone

import bcrypt
from bson import ObjectId


class User:
    """User model — maps to the 'users' MongoDB collection."""

    collection_name = "users"

    @staticmethod
    def create(db, name: str, email: str, password: str) -> dict:
        """Create a new user with a bcrypt-hashed password."""
        password_hash = bcrypt.hashpw(
            password.encode("utf-8"), bcrypt.gensalt()
        ).decode("utf-8")

        user_doc = {
            "name": name,
            "email": email.lower().strip(),
            "password_hash": password_hash,
            "created_at": datetime.now(timezone.utc),
        }
        result = db[User.collection_name].insert_one(user_doc)
        user_doc["_id"] = result.inserted_id
        return user_doc

    @staticmethod
    def find_by_email(db, email: str):
        """Find a user by email address."""
        return db[User.collection_name].find_one({"email": email.lower().strip()})

    @staticmethod
    def find_by_id(db, user_id: str):
        """Find a user by ObjectId."""
        return db[User.collection_name].find_one({"_id": ObjectId(user_id)})

    @staticmethod
    def check_password(stored_hash: str, password: str) -> bool:
        """Verify a password against the stored bcrypt hash."""
        return bcrypt.checkpw(
            password.encode("utf-8"), stored_hash.encode("utf-8")
        )

    @staticmethod
    def to_json(user: dict) -> dict:
        """Serialize a user document for API responses (exclude password)."""
        return {
            "id": str(user["_id"]),
            "name": user["name"],
            "email": user["email"],
            "created_at": user["created_at"].isoformat(),
        }
