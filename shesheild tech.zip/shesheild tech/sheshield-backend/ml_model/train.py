"""
SheShield — CNN Deepfake Detection Model Training Script

Architecture: MobileNetV2 (transfer learning) → Binary classification (Real vs Fake)
Input:        224×224 RGB images, normalized to [0, 1]
Output:       Single sigmoid neuron (0 = real, 1 = fake)

Recommended Datasets:
  - FaceForensics++   → https://github.com/ondyari/FaceForensics
  - Celeb-DF (v2)     → https://github.com/yuezunli/celeb-deepfakeforensics
  - DFDC (Facebook)   → https://ai.facebook.com/datasets/dfdc/

Usage:
  python train.py --data_dir ./dataset --epochs 10 --batch_size 32

Expected dataset structure:
  dataset/
  ├── train/
  │   ├── real/     ← real face images
  │   └── fake/     ← deepfake images
  └── val/
      ├── real/
      └── fake/
"""

import argparse
import os
import sys


def build_model():
    """Build the MobileNetV2-based binary classification model."""
    from tensorflow.keras.applications import MobileNetV2
    from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
    from tensorflow.keras.models import Model

    base_model = MobileNetV2(
        weights="imagenet",
        include_top=False,
        input_shape=(224, 224, 3),
    )

    # Freeze base model layers for transfer learning
    base_model.trainable = False

    x = base_model.output
    x = GlobalAveragePooling2D()(x)
    x = Dropout(0.3)(x)
    x = Dense(128, activation="relu")(x)
    x = Dropout(0.2)(x)
    output = Dense(1, activation="sigmoid")(x)

    model = Model(inputs=base_model.input, outputs=output)
    return model


def train(data_dir: str, epochs: int = 10, batch_size: int = 32,
          output_path: str = "model.h5"):
    """
    Train the deepfake detection model.

    Args:
        data_dir: Path to dataset with train/ and val/ subdirectories.
        epochs: Number of training epochs.
        batch_size: Batch size for training.
        output_path: Where to save the trained model.
    """
    from tensorflow.keras.preprocessing.image import ImageDataGenerator
    from tensorflow.keras.optimizers import Adam
    from tensorflow.keras.callbacks import (
        EarlyStopping,
        ModelCheckpoint,
        ReduceLROnPlateau,
    )

    train_dir = os.path.join(data_dir, "train")
    val_dir = os.path.join(data_dir, "val")

    if not os.path.isdir(train_dir):
        print(f"Error: Training directory not found: {train_dir}")
        sys.exit(1)

    # Data augmentation for training
    train_datagen = ImageDataGenerator(
        rescale=1.0 / 255,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        horizontal_flip=True,
        zoom_range=0.15,
        brightness_range=[0.8, 1.2],
    )

    val_datagen = ImageDataGenerator(rescale=1.0 / 255)

    train_generator = train_datagen.flow_from_directory(
        train_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode="binary",
        classes=["real", "fake"],
    )

    val_generator = val_datagen.flow_from_directory(
        val_dir,
        target_size=(224, 224),
        batch_size=batch_size,
        class_mode="binary",
        classes=["real", "fake"],
    )

    print(f"\nClasses: {train_generator.class_indices}")
    print(f"Training samples: {train_generator.samples}")
    print(f"Validation samples: {val_generator.samples}\n")

    # Build and compile
    model = build_model()
    model.compile(
        optimizer=Adam(learning_rate=1e-4),
        loss="binary_crossentropy",
        metrics=["accuracy"],
    )

    model.summary()

    # Callbacks
    callbacks = [
        EarlyStopping(
            monitor="val_loss", patience=3, restore_best_weights=True
        ),
        ModelCheckpoint(
            output_path, monitor="val_accuracy", save_best_only=True, verbose=1
        ),
        ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=2, min_lr=1e-7
        ),
    ]

    # Train
    history = model.fit(
        train_generator,
        epochs=epochs,
        validation_data=val_generator,
        callbacks=callbacks,
    )

    print(f"\n✅ Model saved to: {output_path}")
    print(f"   Best val accuracy: {max(history.history['val_accuracy']):.4f}")

    return history


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train SheShield deepfake detection model")
    parser.add_argument("--data_dir", type=str, required=True,
                        help="Path to dataset directory (must contain train/ and val/)")
    parser.add_argument("--epochs", type=int, default=10, help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=32, help="Batch size")
    parser.add_argument("--output", type=str, default="model.h5",
                        help="Output model file path")

    args = parser.parse_args()
    train(args.data_dir, args.epochs, args.batch_size, args.output)
