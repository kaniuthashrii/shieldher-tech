"""
SheShield Backend — Main Flask Application
AI-powered women's digital safety app for deepfake & image misuse detection.
"""

import os
from datetime import timedelta

from flask import Flask, g, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager
from pymongo import MongoClient
from werkzeug.exceptions import HTTPException

from config import Config


def create_app():
    """Application factory — creates and configures the Flask app."""
    app = Flask(__name__)

    # Load configuration
    app.config.from_object(Config)
    app.config["MAX_CONTENT_LENGTH"] = Config.MAX_CONTENT_LENGTH
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = Config.JWT_ACCESS_TOKEN_EXPIRES
    app.config["UPLOAD_FOLDER"] = Config.UPLOAD_FOLDER
    app.config["ALLOWED_EXTENSIONS"] = Config.ALLOWED_EXTENSIONS
    app.config["MOCK_MODE"] = Config.MOCK_MODE
    app.config["MODEL_PATH"] = Config.MODEL_PATH

    # Initialize extensions
    CORS(app, origins=Config.CORS_ORIGINS, supports_credentials=True)
    jwt = JWTManager(app)

    # MongoDB connection
    mongo_client = MongoClient(Config.MONGO_URI)
    db = mongo_client[Config.MONGO_DB_NAME]

    # Ensure indexes
    db["users"].create_index("email", unique=True)
    db["images"].create_index("user_id")
    db["scan_results"].create_index("user_id")
    db["alerts"].create_index("user_id")

    # Ensure upload folder exists
    os.makedirs(Config.UPLOAD_FOLDER, exist_ok=True)

    # ------- Per-request DB injection ------- #
    @app.before_request
    def inject_db():
        g.db = db

    # ------- Register Blueprints ------- #
    from routes.auth import auth_bp
    from routes.upload import upload_bp
    from routes.scan import scan_bp
    from routes.alerts import alerts_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(upload_bp)
    app.register_blueprint(scan_bp)
    app.register_blueprint(alerts_bp)

    # ------- Dashboard Stats Route ------- #
    from flask_jwt_extended import jwt_required, get_jwt_identity
    from models.scan_result import ScanResult
    from models.alert import Alert

    @app.route("/api/dashboard/stats", methods=["GET"])
    @jwt_required()
    def dashboard_stats():
        """Return aggregated stats for the logged-in user's dashboard."""
        user_id = get_jwt_identity()
        return {
            "success": True,
            "data": {
                "total_scanned": ScanResult.count_by_user(db, user_id),
                "threats_found": ScanResult.count_threats(db, user_id),
                "alerts_sent": Alert.count_by_user(db, user_id),
            },
            "message": "Dashboard stats retrieved successfully",
        }, 200

    # ------- Error Handlers ------- #
    @app.errorhandler(400)
    def bad_request(e):
        return {"success": False, "error": "Bad request", "code": 400}, 400

    @app.errorhandler(401)
    def unauthorized(e):
        return {"success": False, "error": "Unauthorized", "code": 401}, 401

    @app.errorhandler(403)
    def forbidden(e):
        return {"success": False, "error": "Forbidden", "code": 403}, 403

    @app.errorhandler(404)
    def not_found(e):
        return {"success": False, "error": "Resource not found", "code": 404}, 404

    @app.errorhandler(413)
    def file_too_large(e):
        return {"success": False, "error": "File too large. Max 5MB allowed.", "code": 413}, 413

    @app.errorhandler(422)
    def unprocessable(e):
        return {"success": False, "error": "Unprocessable entity", "code": 422}, 422

    @app.errorhandler(500)
    def internal_error(e):
        return {"success": False, "error": "Internal server error", "code": 500}, 500

    @app.errorhandler(Exception)
    def handle_exception(e):
        """Catch-all error handler for unhandled exceptions."""
        if isinstance(e, HTTPException):
            return {"success": False, "error": e.description, "code": e.code}, e.code
        return {"success": False, "error": "An unexpected error occurred", "code": 500}, 500

    # ------- JWT Error Handlers ------- #
    @jwt.expired_token_loader
    def expired_token(jwt_header, jwt_payload):
        return {"success": False, "error": "Token has expired", "code": 401}, 401

    @jwt.invalid_token_loader
    def invalid_token(error):
        return {"success": False, "error": "Invalid token", "code": 401}, 401

    @jwt.unauthorized_loader
    def missing_token(error):
        return {"success": False, "error": "Authorization token required", "code": 401}, 401

    # ------- Health Check ------- #
    @app.route("/api/health", methods=["GET"])
    def health():
        return {
            "success": True,
            "data": {
                "status": "healthy",
                "mock_mode": Config.MOCK_MODE,
            },
            "message": "SheShield API is running",
        }, 200

    return app


# ------- Entry Point ------- #
if __name__ == "__main__":
    app = create_app()
    print("\n🛡️  SheShield API Server")
    print(f"   Mock Mode: {Config.MOCK_MODE}")
    print(f"   Upload Dir: {Config.UPLOAD_FOLDER}")
    print(f"   MongoDB: {Config.MONGO_DB_NAME}")
    print(f"   Running on http://127.0.0.1:5000\n")
    app.run(host="0.0.0.0", port=5000, debug=Config.DEBUG)
