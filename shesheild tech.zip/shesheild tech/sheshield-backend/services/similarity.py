"""
Similarity Scan Service
Compares uploaded image hashes against all stored hashes to find matches.
Uses Hamming distance on perceptual hashes.
"""

import imagehash


def hamming_distance(hash1: str, hash2: str) -> int:
    """
    Compute Hamming distance between two perceptual hash hex strings.
    Lower = more similar. 0 = identical.
    """
    h1 = imagehash.hex_to_hash(hash1)
    h2 = imagehash.hex_to_hash(hash2)
    return h1 - h2  # imagehash overloads subtraction as Hamming distance


def find_similar_images(target_phash: str, all_images: list,
                        exclude_id=None, threshold: int = 10) -> list:
    """
    Compare the target image's phash against all stored image hashes.

    Args:
        target_phash: Perceptual hash of the image to check.
        all_images: List of image documents with 'phash', '_id', 'user_id', 'filename'.
        exclude_id: ObjectId to exclude from comparison (the image itself).
        threshold: Hamming distance threshold. < threshold = suspicious match.

    Returns:
        List of match dicts sorted by distance:
        [
            {
                "image_id": str,
                "user_id": str,
                "filename": str,
                "distance": int,
                "similarity_pct": float
            },
            ...
        ]
    """
    matches = []

    for img in all_images:
        if img.get("phash") is None:
            continue
        if exclude_id and str(img["_id"]) == str(exclude_id):
            continue

        distance = hamming_distance(target_phash, img["phash"])

        if distance < threshold:
            # Convert Hamming distance to a similarity percentage
            # pHash is 64-bit, so max distance is 64
            similarity_pct = round((1 - distance / 64) * 100, 2)

            matches.append({
                "image_id": str(img["_id"]),
                "user_id": str(img["user_id"]),
                "filename": img.get("filename", "unknown"),
                "distance": distance,
                "similarity_pct": similarity_pct,
            })

    # Sort by distance (most similar first)
    matches.sort(key=lambda m: m["distance"])
    return matches


def get_similarity_score(matches: list) -> float:
    """
    Compute an overall similarity score from matches.
    Returns the highest similarity percentage found, or 0 if no matches.
    """
    if not matches:
        return 0.0
    return matches[0]["similarity_pct"]
