"""
Deepfake Detection Service
Uses a pre-trained CNN (MobileNetV2-based) model to classify images as real or fake.
Falls back to mock mode if model is unavailable or MOCK_MODE is enabled.
"""

import os
import random

import numpy as np
from PIL import Image as PILImage

# Lazy-load TensorFlow to avoid slow startup when in mock mode
_model = None


def _load_model(model_path: str):
    """Load the Keras model from disk (once, cached in module-level variable)."""
    global _model
    if _model is None:
        try:
            from tensorflow.keras.models import load_model
            if os.path.exists(model_path):
                _model = load_model(model_path)
            else:
                _model = "UNAVAILABLE"
        except Exception:
            _model = "UNAVAILABLE"
    return _model


def preprocess_image(image_path: str, target_size: tuple = (224, 224)) -> np.ndarray:
    """
    Preprocess image for the CNN model:
    - Resize to 224×224
    - Normalize pixel values to [0, 1]
    - Expand to batch dimension
    """
    img = PILImage.open(image_path).convert("RGB")
    img = img.resize(target_size)
    img_array = np.array(img, dtype=np.float32) / 255.0
    return np.expand_dims(img_array, axis=0)


def detect_deepfake(image_path: str, model_path: str, mock_mode: bool = False) -> dict:
    """
    Run deepfake detection on the given image.

    Returns:
        {
            "deepfake_score": float (0.0 to 1.0),
            "label": "safe" | "suspicious" | "deepfake",
            "confidence": float
        }

    Scoring logic:
        > 0.7  → deepfake detected
        0.4–0.7 → suspicious
        < 0.4  → safe
    """
    if mock_mode:
        # Return a weighted random score for testing
        score = round(random.triangular(0.0, 1.0, 0.2), 4)
        return _build_result(score)

    model = _load_model(model_path)
    if model == "UNAVAILABLE":
        # Graceful fallback: random score with a warning
        score = round(random.triangular(0.0, 1.0, 0.2), 4)
        result = _build_result(score)
        result["warning"] = "Model not loaded — using mock prediction"
        return result

    # Run real prediction
    preprocessed = preprocess_image(image_path)
    prediction = model.predict(preprocessed, verbose=0)
    score = float(prediction[0][0])
    return _build_result(score)


def _build_result(score: float) -> dict:
    """Convert a raw score into a labelled result."""
    if score > 0.7:
        label = "deepfake"
    elif score >= 0.4:
        label = "suspicious"
    else:
        label = "safe"

    return {
        "deepfake_score": round(score, 4),
        "label": label,
        "confidence": round(abs(score - 0.5) * 2, 4),  # 0 at 0.5, 1 at 0 or 1
    }
