"""
Fingerprinting Service
Generates perceptual hashes and ORB feature vectors for uploaded images.
"""

import imagehash
import numpy as np
from PIL import Image as PILImage

try:
    import cv2
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False


def generate_phash(image_path: str) -> str:
    """
    Generate a perceptual hash (pHash) for the given image.
    Returns the hash as a hex string.
    """
    img = PILImage.open(image_path)
    phash = imagehash.phash(img)
    return str(phash)


def generate_feature_vector(image_path: str, max_features: int = 500) -> list:
    """
    Extract ORB feature descriptors from the image using OpenCV.
    Returns a flattened list of descriptor values (or empty if no features found).
    """
    if not CV2_AVAILABLE:
        return []

    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        return []

    orb = cv2.ORB_create(nfeatures=max_features)
    keypoints, descriptors = orb.detectAndCompute(img, None)

    if descriptors is None:
        return []

    # Flatten and convert to a regular Python list for MongoDB storage
    return descriptors.flatten().tolist()


def generate_fingerprint(image_path: str) -> dict:
    """
    Generate both perceptual hash and ORB feature vector for an image.
    Returns a dict with 'phash' and 'feature_vector' keys.
    """
    phash = generate_phash(image_path)
    feature_vector = generate_feature_vector(image_path)

    return {
        "phash": phash,
        "feature_vector": feature_vector,
    }
