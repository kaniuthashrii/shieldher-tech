# SheShield Backend API

> AI-powered women's digital safety app — deepfake detection & image misuse monitoring.
> **ShieldHer Tech — Hack'Her'Thon 3.0**

---

## 🚀 Quick Start

### Prerequisites

- **Python 3.9+**
- **MongoDB** running locally on `mongodb://localhost:27017`
- **pip** (Python package manager)

### Installation

```bash
# 1. Navigate to backend directory
cd sheshield-backend

# 2. Create virtual environment (recommended)
python -m venv venv
venv\Scripts\activate        # Windows
# source venv/bin/activate   # macOS/Linux

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
# Edit .env file with your settings (defaults work for development)

# 5. Run the server
python app.py
```

The API will start at **http://127.0.0.1:5000**

### Health Check

```
GET http://localhost:5000/api/health
```

---

## 📡 API Endpoints

### Auth

| Method | Endpoint              | Auth | Description           |
|--------|-----------------------|------|-----------------------|
| POST   | `/api/auth/register`  | ❌   | Register new user     |
| POST   | `/api/auth/login`     | ❌   | Login, returns JWT    |
| POST   | `/api/auth/logout`    | ✅   | Logout (discard JWT)  |

### Images

| Method | Endpoint             | Auth | Description                     |
|--------|----------------------|------|---------------------------------|
| POST   | `/api/upload`        | ✅   | Upload image + fingerprint      |
| GET    | `/api/images`        | ✅   | Get all user's images           |
| DELETE | `/api/images/:id`    | ✅   | Delete an image record          |

### Scan

| Method | Endpoint               | Auth | Description                     |
|--------|------------------------|------|---------------------------------|
| POST   | `/api/scan/:image_id`  | ✅   | Run full scan (deepfake + similarity) |
| GET    | `/api/scan/results`    | ✅   | Get all scan results            |

### Alerts

| Method | Endpoint                 | Auth | Description           |
|--------|--------------------------|------|-----------------------|
| GET    | `/api/alerts`            | ✅   | Get all user alerts   |
| POST   | `/api/alerts`            | ✅   | Create manual alert   |
| PATCH  | `/api/alerts/:id/read`   | ✅   | Mark alert as read    |

### Dashboard

| Method | Endpoint                | Auth | Description           |
|--------|-------------------------|------|-----------------------|
| GET    | `/api/dashboard/stats`  | ✅   | Get aggregated stats  |

---

## 🔐 Authentication

All protected endpoints require a JWT token in the `Authorization` header:

```
Authorization: Bearer <your_jwt_token>
```

### Register

```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name": "Jane Doe", "email": "jane@example.com", "password": "secure123"}'
```

### Login

```bash
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email": "jane@example.com", "password": "secure123"}'
```

---

## 📤 Upload & Scan Flow

```bash
# 1. Upload an image
curl -X POST http://localhost:5000/api/upload \
  -H "Authorization: Bearer <TOKEN>" \
  -F "file=@photo.jpg"

# 2. Run scan on the uploaded image
curl -X POST http://localhost:5000/api/scan/<image_id> \
  -H "Authorization: Bearer <TOKEN>"

# 3. Check alerts
curl http://localhost:5000/api/alerts \
  -H "Authorization: Bearer <TOKEN>"
```

---

## 📋 API Response Format

**Success:**
```json
{
  "success": true,
  "data": { ... },
  "message": "Operation completed successfully"
}
```

**Error:**
```json
{
  "success": false,
  "error": "Error description",
  "code": 400
}
```

---

## 🧠 AI/ML — Mock Mode

By default, `MOCK_MODE=True` in `.env`, which means the deepfake detector returns random scores for testing. This lets the frontend work immediately without a trained model.

To use a real model:

1. Train the model:
   ```bash
   python ml_model/train.py --data_dir ./dataset --epochs 10
   ```
2. Set `MOCK_MODE=False` in `.env`
3. Ensure `MODEL_PATH=ml_model/model.h5` points to the trained model

### Recommended Datasets

- [FaceForensics++](https://github.com/ondyari/FaceForensics)
- [Celeb-DF v2](https://github.com/yuezunli/celeb-deepfakeforensics)
- [DFDC (Facebook)](https://ai.facebook.com/datasets/dfdc/)

---

## 🗂️ Project Structure

```
sheshield-backend/
├── app.py                  # Main Flask app entry point
├── config.py               # Configuration from .env
├── requirements.txt        # Dependencies
├── .env                    # Environment variables
├── routes/
│   ├── auth.py             # Register / Login / Logout
│   ├── upload.py           # Image upload & fingerprinting
│   ├── scan.py             # Similarity + deepfake scan
│   └── alerts.py           # Alert CRUD
├── models/
│   ├── user.py             # User model (MongoDB)
│   ├── image.py            # Image record model
│   ├── alert.py            # Alert model
│   └── scan_result.py      # Scan result model
├── services/
│   ├── fingerprint.py      # Perceptual hashing (pHash + ORB)
│   ├── deepfake.py         # CNN deepfake detection
│   └── similarity.py       # Hamming distance comparison
├── ml_model/
│   ├── train.py            # Model training script
│   └── model.h5            # Pre-trained model (after training)
└── uploads/                # Temporary uploaded images
```

---

## ⚙️ Environment Variables

| Variable                   | Default                    | Description                  |
|----------------------------|----------------------------|------------------------------|
| `SECRET_KEY`               | `your-super-secret-key`    | Flask secret key             |
| `JWT_SECRET_KEY`           | `jwt-secret-key`           | JWT signing key              |
| `JWT_ACCESS_TOKEN_EXPIRES` | `86400`                    | Token lifetime (seconds)     |
| `MONGO_URI`                | `mongodb://localhost:27017/`| MongoDB connection URI      |
| `MONGO_DB_NAME`            | `sheshield`                | Database name                |
| `UPLOAD_FOLDER`            | `uploads`                  | Upload directory             |
| `MAX_CONTENT_LENGTH`       | `5242880`                  | Max file size (5MB)          |
| `MOCK_MODE`                | `True`                     | Use mock AI predictions      |
| `MODEL_PATH`               | `ml_model/model.h5`        | Path to CNN model            |
| `CORS_ORIGINS`             | `*`                        | Allowed CORS origins         |
