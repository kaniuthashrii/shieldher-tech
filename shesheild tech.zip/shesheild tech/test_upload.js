const fs = require('fs');
const path = require('path');

async function testUpload() {
    try {
        // Create a dummy image file
        const dummyPath = path.join(__dirname, 'test.jpg');
        fs.writeFileSync(dummyPath, 'fake image content');

        // We need a token first
        const loginRes = await fetch('http://localhost:5000/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: 'test2@example.com', password: 'password123' })
        });
        const loginData = await loginRes.json();
        const token = loginData.data.access_token;

        // Now upload
        const formData = new FormData();
        const fileContent = fs.readFileSync(dummyPath);
        const blob = new Blob([fileContent], { type: 'image/jpeg' });
        formData.append('file', blob, 'test.jpg');

        const uploadRes = await fetch('http://localhost:5000/api/upload', {
            method: 'POST',
            headers: { 'Authorization': `Bearer ${token}` },
            body: formData
        });

        const uploadData = await uploadRes.json();
        console.log('UPLOAD RESPONSE:', JSON.stringify(uploadData, null, 2));

        // Cleanup
        fs.unlinkSync(dummyPath);

    } catch (e) {
        console.error('ERROR:', e.message);
    }
}

testUpload();
